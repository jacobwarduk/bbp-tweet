=== Plugin Name ===
Contributors: jacobwarduk
Donate link: http://www.jacobward.co.uk/bbp-tweet/
Tags: bbpress, bbp, twitter, tweet, automation, bbp-tweet
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

bbPress plugin to automatically tweet new topics and replies.


== Description ==

## bbp tweet

bbPress plugin to automatically tweet new topics and replies.


== Installation ==

1. Upload `bbp-tweet.zip` to the `/wp-content/plugins/` directory.
2. Create a directory named `bbp-tweet` and unzip bbp-tweet.zip into the directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Look for the 'bbp tweet' menu option in the WordPress dashboard to change settings.

Alternatively

1. Go to the 'Add New' page from the 'Plugins' menu in WordPress.
2. Click on 'Upload Plugin'.
3. Browse your computer and upload the `bbp-tweet.zip` file.
4. Follow instructions on screen.
4. Look for the 'bbp tweet' menu option in the WordPress dashboard to change settings.


== Changelog ==

= 1.0 =
* Fully working version.
