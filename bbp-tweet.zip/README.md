# bbp tweet

bbPress plugin to automatically tweet new topics and replies.

### To Do ###
 - Refactor code.
 - Add custom prefix/suffix options.
